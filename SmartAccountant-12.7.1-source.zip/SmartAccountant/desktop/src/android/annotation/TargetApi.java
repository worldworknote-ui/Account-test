package android.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.SOURCE) public @interface TargetApi { int value(); }
