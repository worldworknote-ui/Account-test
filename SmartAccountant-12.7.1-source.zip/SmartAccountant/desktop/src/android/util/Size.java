package android.util;
public class Size { final int w, h; public Size(int w, int h) { this.w = w; this.h = h; } public int getWidth() { return w; } public int getHeight() { return h; } }
